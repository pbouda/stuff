<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="helloworld.ui" line="14"/>
        <source>Hello World</source>
        <translation>Hallo Welt</translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="21"/>
        <source>Hello World!</source>
        <translation>Hallo Welt!</translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="31"/>
        <source>Update</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="48"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="60"/>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="65"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="70"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="helloworld.ui" line="75"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
