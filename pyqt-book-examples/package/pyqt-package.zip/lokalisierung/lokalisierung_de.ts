<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
    <name>MyMainWindow</name>
    <message>
        <location filename="lokalisierung.py" line="32"/>
        <source>Hello World</source>
        <translation>Hallo Welt</translation>
    </message>
    <message>
        <location filename="lokalisierung.py" line="46"/>
        <source>Hello {0}!</source>
        <translation type="unfinished">{0} sei gegrüßt!</translation>
    </message>
    <message>
        <location filename="lokalisierung.py" line="45"/>
        <source>Update</source>
        <translation type="obsolete">Akutalisieren</translation>
    </message>
    <message>
        <location filename="lokalisierung.py" line="47"/>
        <source>Insert</source>
        <translation type="unfinished">Aktualisieren</translation>
    </message>
</context>
</TS>
