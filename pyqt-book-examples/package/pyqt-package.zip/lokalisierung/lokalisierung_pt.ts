<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>MyMainWindow</name>
    <message>
        <location filename="lokalisierung.py" line="32"/>
        <source>Hello World</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lokalisierung.py" line="46"/>
        <source>Hello {0}!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="lokalisierung.py" line="47"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
