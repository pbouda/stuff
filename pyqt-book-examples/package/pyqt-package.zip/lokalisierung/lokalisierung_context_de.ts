<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>A</name>
    <message>
        <location filename="lokalisierung_context.py" line="10"/>
        <source>Hello</source>
        <translation>Hallo</translation>
    </message>
</context>
</TS>
